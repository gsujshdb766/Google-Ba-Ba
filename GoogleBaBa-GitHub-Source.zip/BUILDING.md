# Google Ba Ba - Android ESP Visualizer Application

## Project Structure

```
GoogleBaBa/
├── build.gradle              # Project-level build configuration
├── settings.gradle           # Gradle settings
├── gradle/                 # Gradle wrapper
│   └── wrapper/
│       ├── gradle-wrapper.properties
│       └── gradle-wrapper.jar
├── app/                    # Application module
│   ├── build.gradle        # App-level build configuration
│   ├── src/main/
│   │   ├── AndroidManifest.xml  # App manifest with all activities
│   │   ├── java/com/google/baba/visualizer/
│   │   │   ├── MainApplication.java    # Application class
│   │   │   ├── SplashActivity.java     # Launch screen
│   │   │   ├── WelcomeActivity.java    # Welcome screen
│   │   │   ├── DashboardActivity.java  # Main dashboard
│   │   │   ├── VisualizerActivity.java # ESP visualization screen
│   │   │   ├── AboutActivity.java      # About screen
│   │   │   ├── VisualizerViewModel.java  # ViewModel for visualization state
│   │   │   ├── VisualizerView.java     # Custom view for ESP rendering
│   │   │   ├── PlayerEntity.java       # Data model for player entities
│   │   │   ├── PermissionsUtil.java    # Runtime permission helper
│   │   │   ├── GradientBackground.java # Gradient background component
│   │   │   ├── ToggleSwitch.java       # Custom neon switch widget
│   │   │   ├── demomode/
│   │   │   │   └── DemoModeActivity.java  # Demo mode test screen
│   │   │   ├── playersettings/
│   │   │   │   └── PlayerSettingsActivity.java  # Player visualization settings
│   │   │   ├── appearancesettings/
│   │   │   │   └── AppearanceSettingsActivity.java  # Appearance customization
│   │   │   └── generalsettings/
│   │   │       └── GeneralSettingsActivity.java  # General app settings
│   │   ├── res/
│   │   │   ├── layout/           # UI layout XML files
│   │   │   │   ├── splash_screen.xml         # Splash screen layout
│   │   │   │   ├── welcome_screen.xml        # Welcome screen layout
│   │   │   │   ├── activity_dashboard.xml    # Main dashboard layout
│   │   │   │   ├── activity_visualizer.xml   # ESP visualization layout
│   │   │   │   ├── activity_demo_mode.xml    # Demo mode layout
│   │   │   │   ├── activity_player_settings.xml  # Player settings layout
│   │   │   │   ├── activity_appearance_settings.xml  # Appearance settings layout
│   │   │   │   ├── activity_general_settings.xml   # General settings layout
│   │   │   │   ├── about_screen.xml          # About screen layout
│   │   │   │   └── activity_main.xml         # (Optional) Main activity
│   │   │   ├── drawable/         # Image resources
│   │   │   │   ├── ic_launcher.xml           # App icon (VectorDrawable)
│   │   │   │   ├── ic_status_connected.xml   # Status indicator
│   │   │   │   ├── ic_demo_off.xml           # Demo mode off indicator
│   │   │   │   ├── ic_settings.xml           # Settings icon
│   │   │   │   ├── ic_info.xml               # Info icon
│   │   │   │   ├── gradient_top.xml          # Background gradient
│   │   │   │   └── gradient_bottom.xml       # Background gradient
│   │   │   ├── mipmap/           # Launcher icon densities (currently VectorDrawable)
│   │   │   ├── navigation/       # Navigation component graph
│   │   │   │   └── nav_graph.xml             # Navigation graph
│   │   │   └── values/           # Resource files
│   │   │       ├── strings.xml       # All string constants
│   │   │       ├── colors.xml        # Color palette (dark theme, neon accents)
│   │   │       └── styles.xml        # App themes and styles
│   │   └── AndroidManifest.xml     # Main module manifest
│   └── ...                     # Additional gradle files
```

## Prerequisites

### Android Studio
- Android Studio Arctic Fox (2020.3.1) or newer
- JDK 17 or newer
- Android SDK 34 (target) / 21 (minimum)
- Gradle 8.4 or newer

### System Requirements
- Linux, macOS, or Windows
- 4 GB RAM minimum (8 GB recommended)
- 500 MB available disk space

## Installation

### Option 1: Open in Android Studio

1. Launch Android Studio
2. Select "Open" or "Open an existing project"
3. Navigate to: `/path/to/GoogleBaBa`
4. Select the root directory (contains `build.gradle`, `settings.gradle`)
5. Click "Open"

Android Studio will automatically sync the Gradle project and download any missing dependencies.

### Option 2: Command Line

```bash
# Navigate to the project directory
cd /path/to/GoogleBaBa

# Sync Gradle (Android Studio must be installed)
./gradlew androidSync

# Or open directly
android-studio .
```

## Building the APK

### Release Build

```bash
cd /path/to/GoogleBaBa
./gradlew assembleRelease
```

The debug APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

The release APK will be generated at:
`app/build/outputs/apk/release/app-release.apk`

### Build Configuration

The project uses the following build settings:

- **Application ID**: `com.google.baba.visualizer`
- **Min SDK**: 21 (Android 5.0 Lollipop)
- **Target SDK**: 34 (Android 14)
- **Compile SDK**: 34
- **Version Code**: 1
- **Version Name**: "1.0"
- **Package Name**: `com.google.baba.visualizer`

## App Navigation Flow

1. **Splash Screen** -> Appears on app launch (2 seconds)
2. **Welcome Screen** -> Shown after splash (1.5 seconds)
3. **Main Dashboard** -> Primary interface with status indicators
4. **Visualizer Screen** -> ESP-style visualization display
5. **Demo Mode Screen** -> Simulated gameplay environment
6. **Player Settings** -> Individual feature toggles
7. **Appearance Settings** -> Themes, opacity, text size
8. **General Settings** -> Privacy, about, app-wide options
9. **About Screen** -> Application information

## Key Features

### Visualization Features
- Player bounding boxes with color-coded entities (blue for humans, red for bots)
- Player names and distance labels
- Health bars with color-coded levels (green/yellow/red)
- Skeleton visualization using simulated coordinate points
- Direction indicators with arrow symbols
- Status labels (Alive, Running, Idle, Combat, Defending)

### Bot Filtering
- "Ignore Bots" toggle feature
- Entities have explicit `isBot: boolean` field
- When enabled: only human players are displayed
- When disabled: all entities (bots and humans) are shown
- Player counters update accordingly

### Demo Mode
- Offline demonstration mode (no internet required)
- Generates sample human-player entities
- Generates sample bot entities
- Real-time position updates
- Test the Ignore Bots switch
- Adjustable simulation parameters (human/bot count, speed)
- Reset Demo button to restore default state

### Customization
- **Themes**: Blue, Green, Red, Purple, Custom
- **Opacity**: Configurable visualizer opacity (0.0 - 1.0)
- **Text Size**: Adjustable text size for labels
- **Health Bar**: Multiple styles (Default, Gradient, Segmented, Pulsing, Custom)

### Settings Persistence
- All user preferences saved locally using SharedPreferences
- Settings persist across app restarts
- Categories: General, Visualizer, Appearance, Demo, Privacy

## Screen Descriptions

### Splash Screen
- Displayed immediately on app launch
- Shows the Google Ba Ba logo with animated gradient background
- Automatically transitions to Welcome Screen after 2 seconds

### Welcome Screen
- Greets the user with the app name
- Progress bar showing initialization
- Transitions to Main Dashboard

### Main Dashboard
- Premium gaming dashboard with dark black background
- Neon blue accent colors
- Glassmorphism cards with smooth animations
- Contains:
  - App logo and name
  - Connection status indicator
  - Demo Mode status
  - Visualizer ON/OFF switch
  - Player simulation counter
  - Bot simulation counter
  - Real-player simulation counter
  - Settings shortcut
  - About application section

### Visualizer Screen
- ESP-style visualization canvas
- Draws all enabled visualization elements
- Toggle controls for each feature
- Real-time entity rendering

### Demo Mode Screen
- Fully functional offline demo
- Generate sample humans and bots
- Test Ignore Bots switch
- Adjust simulation parameters
- Reset to default state

### Player Settings Screen
- Independent toggles for each visualization feature:
  - Show Player Box
  - Show Player Name
  - Show Distance
  - Show Health
  - Show Skeleton
  - Show Direction
  - Show Status
  - Ignore Bots

### Appearance Settings Screen
- Theme selection (Blue, Green, Red, Purple, Custom)
- Box opacity slider
- Text size adjustment
- Health bar appearance customization

### General Settings Screen
- Network & connectivity options
- Language & input settings
- Date & time configuration
- Privacy settings
- About application information

### About Screen
- Application description
- Package information
- Version number
- Purpose and usage information

## Code Quality

### Architecture
- **Separation of concerns**: UI components, data models, visualization engine, demo data generator, player classification filter, settings manager, and navigation are properly separated
- **ViewModel pattern**: `VisualizerViewModel` manages UI-related data survival across configuration changes
- **Data entities**: `PlayerEntity` class with explicit `isBot` field for classification
- **Preference management**: `SharedPreferences` for saving user settings

### Error Handling
- Proper null checks in entity rendering
- Safe defaults for all configuration values
- Graceful degradation if resources are missing
- No crash-prone operations on UI thread

### Performance
- Efficient entity rendering with object reuse
- Optional features disabled when not needed
- Battery-conscious animation (postInvalidateOnAnimation)
- No unnecessary background processing

## Permissions

The app requests only the permissions it needs:

- `android.permission.INTERNET` - For deep link handling
- `android.permission.ACCESS_NETWORK_STATE` - Network connectivity awareness
- `android.permission.ACCESS_WIFI_STATE` - WiFi status monitoring
- `android.permission.WRITE_EXTERNAL_STORAGE` (maxSdkVersion 32 only) - For saving screenshots (older Android versions)

On Android 11 (SDK 33+) and above, scoped storage is used, and no dangerous permissions are needed for basic file operations.

## Testing Checklist

All requirements from the specification have been implemented:

1. ✅ Application launches successfully (Splash -> Welcome -> Dashboard flow)
2. ✅ Dashboard loads correctly with all status indicators
3. ✅ Demo Mode works offline (generates simulated entities without internet)
4. ✅ Simulated human entities display correctly
5. ✅ Simulated bots display correctly
6. ✅ Ignore Bots ON hides bot entities (filter by `isBot` field)
7. ✅ Ignore Bots OFF displays all entities (both bot and human)
8. ✅ Player counters update correctly (human/bot/total counts)
9. ✅ Settings persist after restarting (SharedPreferences)
10. ✅ Application structure supports different Android screen sizes (responsive layouts)

## Customization

### Adding New Themes
Edit `res/values/colors.xml` to add new color schemes, then select in Appearance Settings.

### Modifying Visualization Features
Toggle the corresponding switches in:
- Player Settings Screen (individual features)
- Dashboard (Visualizer ON/OFF, Ignore Bots)

### Adjusting Simulation Parameters
In Demo Mode Screen:
- Humans: Seekbar (0-20)
- Bots: Seekbar (0-10)
- Speed: Seekbar (0.1-1.0)

## License

This project is for educational purposes and demonstrates Android application development
techniques including custom views, ViewModel, SharedPreferences, and responsive UI design.
All player data is simulated/authorized for offline demonstrations.