package com.google.baba.visualizer.dashboard;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.google.baba.visualizer.MainApplication;
import com.google.baba.visualizer.R;
import com.google.baba.visualizer.visualizer.VisualizerViewModel;

public class DashboardActivity extends AppCompatActivity {

    private VisualizerViewModel viewModel;
    private int playerCount = 0;
    private int botCount = 0;
    private int humanCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize ViewModel
        viewModel = new ViewModelProvider(this).get(VisualizerViewModel.class);

        // Initialize UI components and observers
        initializeUI();

        // Observe demo mode changes
        observeDemoMode();

        // Start simulated data updates
        startSimulation();
    }

    private void initializeUI() {
        // Connection status
        findViewById(R.id.llConnectionStatus).setOnClickListener(v -> {
            // Toggle connection status
            viewModel.setConnected(!viewModel.isConnected());
            updateConnectionStatus();
        });

        // Demo mode status
        findViewById(R.id.llDemoModeStatus).setOnClickListener(v -> {
            viewModel.setDemoMode(!viewModel.isDemoMode());
            updateDemoStatus();
        });

        // Visualizer switch
        findViewById(R.id.swVisualizer).setOnClickListener(v -> {
            boolean isOn = ((android.widget.Switch) v).isChecked();
            viewModel.setVisualizerEnabled(isOn);
            updateVisualizerStatus();
        });

        // Player counter click
        findViewById(R.id.llPlayerCounter).setOnClickListener(v -> {
            // Navigate to player settings or show detail
        });

        // Bot counter click
        findViewById(R.id.llBotCounter).setOnClickListener(v -> {
            // Navigate to ignore bots setting
        });

        // Human counter click
        findViewById(R.id.llHumanCounter).setOnClickListener(v -> {
            // Navigate to player info
        });

        // Settings shortcut
        findViewById(R.id.llSettingsShortcut).setOnClickListener(v -> {
            // Navigate to settings
        });

        // About shortcut
        findViewById(R.id.llAboutShortcut).setOnClickListener(v -> {
            // Navigate to about
        });
    }

    private void observeDemoMode() {
        viewModel.isDemoMode().observe(this, isDemo -> {
            updateDemoStatus();
            if (isDemo) {
                startDemoSimulation();
            }
        });
    }

    private void startSimulation() {
        // Start periodic simulation update
        new Handler().postDelayed(this::updateSimulation, 1000);
    }

    private void updateSimulation() {
        if (viewModel.isVisualizerEnabled() && viewModel.isDemoMode()) {
            // Generate simulated entities
            viewModel.updateSimulatedEntities();
        }
        // Schedule next update
        startSimulation();
    }

    private void updateConnectionStatus() {
        boolean connected = viewModel.isConnected();
        int visibility = connected ? android.view.View.VISIBLE : android.view.View.GONE;
        findViewById(R.id.llConnectionStatus).setVisibility(visibility);
    }

    private void updateDemoStatus() {
        boolean isDemo = viewModel.isDemoMode();
        findViewById(R.id.llDemoModeStatus).setVisibility(isDemo ? android.view.View.VISIBLE : android.view.View.GONE);
        // Update demo icon
        // findViewById(R.id.ivDemoStatusIcon).setImageResource(isDemo ? R.drawable.ic_demo_on : R.drawable.ic_demo_off);
    }

    private void updateVisualizerStatus() {
        boolean isOn = viewModel.isVisualizerEnabled();
        // Update UI based on visualizer state
    }
}