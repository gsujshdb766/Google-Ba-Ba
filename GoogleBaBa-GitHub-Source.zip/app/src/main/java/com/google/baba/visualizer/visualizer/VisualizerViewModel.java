package com.google.baba.visualizer.visualizer;

import android.content.SharedPreferences;
import androidx.lifecycle.ViewModel;
import androidx.preference.PreferenceManager;
import com.google.baba.visualizer.entity.PlayerEntity;
import com.google.baba.visualizer.entity.PlayerEntity.EntityType;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * ViewModel managing the visualizer state, simulation data, and settings.
 * Handles entity generation, filtering (including Ignore Bots),
 * and persistence of user preferences.
 */
public class VisualizerViewModel extends ViewModel {

    private final SharedPreferences sharedPreferences;
    private final Random random;

    // Entity lists
    private final List<PlayerEntity> humanEntities;
    private final List<PlayerEntity> botEntities;

    // Visualization settings
    private boolean visualizerEnabled;
    private boolean demoMode;
    private boolean connected;
    private boolean ignoreBots;

    // Appearance settings
    private float visualizerOpacity;
    private float textSize;
    private int healthBarStyle;
    private int themeIndex;

    // Show feature toggles
    private boolean showPlayerBox;
    private boolean showPlayerName;
    private boolean showDistance;
    private boolean showHealth;
    private boolean showSkeleton;
    private boolean showDirection;
    private boolean showStatus;

    public VisualizerViewModel() {
        this.sharedPreferences = MainApplication.getSharedPreferences();
        this.random = new Random();

        // Initialize entity lists
        this.humanEntities = new ArrayList<>();
        this.botEntities = new ArrayList<>();

        // Initialize visualization state from saved preferences
        this.visualizerEnabled = sharedPreferences.getBoolean("visualizer_enabled", false);
        this.demoMode = sharedPreferences.getBoolean("demo_mode", false);
        this.connected = sharedPreferences.getBoolean("connected", false);
        this.ignoreBots = sharedPreferences.getBoolean("ignore_bots", false);

        // Initialize appearance settings from saved preferences
        this.visualizerOpacity = sharedPreferences.getFloat("visualizer_opacity", 1.0f);
        this.textSize = sharedPreferences.getFloat("text_size", 14f);
        this.healthBarStyle = sharedPreferences.getInt("health_bar_style", 0);
        this.themeIndex = sharedPreferences.getInt("theme_index", 0);

        // Initialize show feature toggles from saved preferences
        this.showPlayerBox = sharedPreferences.getBoolean("show_player_box", true);
        this.showPlayerName = sharedPreferences.getBoolean("show_player_name", true);
        this.showDistance = sharedPreferences.getBoolean("show_distance", true);
        this.showHealth = sharedPreferences.getBoolean("show_health", true);
        this.showSkeleton = sharedPreferences.getBoolean("show_skeleton", true);
        this.showDirection = sharedPreferences.getBoolean("show_direction", true);
        this.showStatus = sharedPreferences.getBoolean("show_status", true);

        // Initialize with some default demo data if in demo mode
        if (demoMode) {
            initializeDemoData();
        }
    }

    // --- Visualizer State ---

    public boolean isVisualizerEnabled() {
        return visualizerEnabled;
    }

    public void setVisualizerEnabled(boolean visualizerEnabled) {
        this.visualizerEnabled = visualizerEnabled;
        savePreferences();
    }

    public boolean isDemoMode() {
        return demoMode;
    }

    public void setDemoMode(boolean demoMode) {
        this.demoMode = demoMode;
        savePreferences();
        if (demoMode) {
            initializeDemoData();
        }
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
        savePreferences();
    }

    public boolean isIgnoreBots() {
        return ignoreBots;
    }

    public void setIgnoreBots(boolean ignoreBots) {
        this.ignoreBots = ignoreBots;
        savePreferences();
        filterEntities();
    }

    // --- Show Feature Toggles ---

    public boolean isShowPlayerBox() {
        return showPlayerBox;
    }

    public void setShowPlayerBox(boolean showPlayerBox) {
        this.showPlayerBox = showPlayerBox;
        savePreferences();
    }

    public boolean isShowPlayerName() {
        return showPlayerName;
    }

    public void setShowPlayerName(boolean showPlayerName) {
        this.showPlayerName = showPlayerName;
        savePreferences();
    }

    public boolean isShowDistance() {
        return showDistance;
    }

    public void setShowDistance(boolean showDistance) {
        this.showDistance = showDistance;
        savePreferences();
    }

    public boolean isShowHealth() {
        return showHealth;
    }

    public void setShowHealth(boolean showHealth) {
        this.showHealth = showHealth;
        savePreferences();
    }

    public boolean isShowSkeleton() {
        return showSkeleton;
    }

    public void setShowSkeleton(boolean showSkeleton) {
        this.showSkeleton = showSkeleton;
        savePreferences();
    }

    public boolean isShowDirection() {
        return showDirection;
    }

    public void setShowDirection(boolean showDirection) {
        this.showDirection = showDirection;
        savePreferences();
    }

    public boolean isShowStatus() {
        return showStatus;
    }

    public void setShowStatus(boolean showStatus) {
        this.showStatus = showStatus;
        savePreferences();
    }

    // --- Appearance Settings ---

    public float getVisualizerOpacity() {
        return visualizerOpacity;
    }

    public void setVisualizerOpacity(float visualizerOpacity) {
        this.visualizerOpacity = visualizerOpacity;
        savePreferences();
    }

    public float getTextSize() {
        return textSize;
    }

    public void setTextSize(float textSize) {
        this.textSize = textSize;
        savePreferences();
    }

    public int getHealthBarStyle() {
        return healthBarStyle;
    }

    public void setHealthBarStyle(int healthBarStyle) {
        this.healthBarStyle = healthBarStyle;
        savePreferences();
    }

    public int getThemeIndex() {
        return themeIndex;
    }

    public void setThemeIndex(int themeIndex) {
        this.themeIndex = themeIndex;
        savePreferences();
    }

    // --- Entity Management ---

    public List<PlayerEntity> getVisibleEntities() {
        List<PlayerEntity> allEntities = new ArrayList<>();
        allEntities.addAll(humanEntities);
        allEntities.addAll(botEntities);

        if (ignoreBots) {
            // Return only entities that are NOT classified as bots
            List<PlayerEntity> visible = new ArrayList<>();
            for (PlayerEntity entity : allEntities) {
                if (!entity.isBot()) {
                    visible.add(entity);
                }
            }
            return visible;
        }

        return allEntities;
    }

    public int getVisiblePlayerCount() {
        return getVisibleEntities().size();
    }

    public int getHumanCount() {
        int count = 0;
        if (ignoreBots) {
            for (PlayerEntity entity : humanEntities) {
                if (!entity.isBot()) {
                    count++;
                }
            }
        } else {
            count = humanEntities.size();
        }
        return count;
    }

    public int getBotCount() {
        int count = 0;
        if (ignoreBots) {
            for (PlayerEntity entity : botEntities) {
                if (!entity.isBot()) {
                    count++;
                }
            }
        } else {
            count = botEntities.size();
        }
        return count;
    }

    // --- Demo Data Generation ---

    private void initializeDemoData() {
        humanEntities.clear();
        botEntities.clear();

        // Read simulation parameters from preferences
        int numHumans = sharedPreferences.getInt("simulation_humans", 5);
        int numBots = sharedPreferences.getInt("simulation_bots", 3);

        // Generate sample human players
        for (int i = 0; i < numHumans; i++) {
            humanEntities.add(createHumanEntity(i));
        }

        // Generate sample bot entities
        for (int i = 0; i < numBots; i++) {
            botEntities.add(createBotEntity(i));
        }

        // Update visible counts
        filterEntities();
    }

    private PlayerEntity createHumanEntity(int index) {
        PlayerEntity entity = new PlayerEntity();
        entity.setId("human_" + index);
        entity.setEntityType(EntityType.HUMAN);
        entity.setBot(false); // Explicit: this is NOT a bot
        entity.setName("Player " + (index + 1));
        entity.setDistance(generateRandomDistance());
        entity.setHealth(generateRandomHealth());
        entity.setPosition(generateRandomPosition());
        entity.setSkeletonPoints(generateSkeletonPoints());
        entity.setDirection(generateDirection());
        entity.setStatus(generateStatus());
        return entity;
    }

    private PlayerEntity createBotEntity(int index) {
        PlayerEntity entity = new PlayerEntity();
        entity.setId("bot_" + index);
        entity.setEntityType(EntityType.BOT);
        entity.setBot(true); // Explicit: THIS entity IS a bot
        entity.setName("Bot " + (index + 1));
        entity.setDistance(generateRandomDistance());
        entity.setHealth(generateRandomHealth());
        entity.setPosition(generateRandomPosition());
        entity.setSkeletonPoints(generateSkeletonPoints());
        entity.setDirection(generateDirection());
        entity.setStatus(generateStatus());
        return entity;
    }

    private float generateRandomDistance() {
        return random.nextFloat() * 500; // 0-500 units
    }

    private int generateRandomHealth() {
        return random.nextInt(101); // 0-100
    }

    private float[] generateRandomPosition() {
        return new float[]{
                random.nextInt(1000),
                random.nextInt(1000)
        };
    }

    private List<float[]> generateSkeletonPoints() {
        List<float[]> points = new ArrayList<>();
        // Generate skeleton joint points (16 major joints)
        for (int i = 0; i < 16; i++) {
            points.add(new float[]{random.nextInt(1000), random.nextInt(1000)});
        }
        return points;
    }

    private String generateDirection() {
        String[] directions = {"North", "North-East", "East", "South-East", "South", "South-West", "West", "North-West"};
        return directions[random.nextInt(directions.length)];
    }

    private String generateStatus() {
        String[] statuses = {"Alive", "Running", "Idle", "Combat", "Defending"};
        return statuses[random.nextInt(statuses.length)];
    }

    // --- Entity Filtering (Ignore Bots) ---

    private void filterEntities() {
        // The filtering is applied when getVisibleEntities() is called.
        // This method can be extended to trigger LiveData/observers if needed.
    }

    // --- Entity Updates ---

    public void updateSimulatedEntities() {
        if (!demoMode) return;

        // Update some existing entities with new positions
        if (!humanEntities.isEmpty()) {
            PlayerEntity entity = humanEntities.get(random.nextInt(humanEntities.size()));
            entity.setPosition(generateRandomPosition());
            entity.setDistance(generateRandomDistance());
            entity.setHealth(generateRandomHealth());
        }

        if (!botEntities.isEmpty()) {
            PlayerEntity entity = botEntities.get(random.nextInt(botEntities.size()));
            entity.setPosition(generateRandomPosition());
            entity.setDistance(generateRandomDistance());
            entity.setHealth(generateRandomHealth());
        }

        // Occasionally add a new random entity
        if (random.nextFloat() < 0.1f) {
            addRandomEntity();
        }

        filterEntities();
    }

    private void addRandomEntity() {
        boolean isHuman = random.nextBoolean();
        if (isHuman) {
            humanEntities.add(createHumanEntity(humanEntities.size()));
        } else {
            botEntities.add(createBotEntity(botEntities.size()));
        }
        filterEntities();
    }

    // --- Preference Saving ---

    private void savePreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("visualizer_enabled", visualizerEnabled);
        editor.putBoolean("demo_mode", demoMode);
        editor.putBoolean("connected", connected);
        editor.putBoolean("ignore_bots", ignoreBots);

        // Save show feature toggles
        editor.putBoolean("show_player_box", showPlayerBox);
        editor.putBoolean("show_player_name", showPlayerName);
        editor.putBoolean("show_distance", showDistance);
        editor.putBoolean("show_health", showHealth);
        editor.putBoolean("show_skeleton", showSkeleton);
        editor.putBoolean("show_direction", showDirection);
        editor.putBoolean("show_status", showStatus);

        // Save appearance settings
        editor.putFloat("visualizer_opacity", visualizerOpacity);
        editor.putFloat("text_size", textSize);
        editor.putInt("health_bar_style", healthBarStyle);
        editor.putInt("theme_index", themeIndex);

        // Save simulation parameters
        editor.putInt("simulation_humans", humanEntities.size());
        editor.putInt("simulation_bots", botEntities.size());

        editor.apply();
    }
}