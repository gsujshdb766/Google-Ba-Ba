package com.google.baba.visualizer.appearancesettings;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.baba.visualizer.R;
import com.google.baba.visualizer.visualizer.VisualizerView;
import com.google.baba.visualizer.visualizer.VisualizerViewModel;

/**
 * Appearance Settings screen for customizing the visualizer's look and feel.
 * Includes theme selection, opacity, text size, and health bar appearance.
 */
public class AppearanceSettingsActivity extends AppCompatActivity {

    private VisualizerView visualizerView;
    private VisualizerViewModel viewModel;

    // UI references
    private android.widget.SeekBar seekBarOpacity;
    private android.widget.SeekBar seekBarTextSize;
    private android.widget.SeekBar seekBarHealthBar;
    private android.widget.RadioGroup radioGroupTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appearance_settings);

        // Initialize ViewModel and UI components
        viewModel = new VisualizerViewModel();
        visualizerView = findViewById(R.id.visualizerView);

        // Initialize UI elements
        initializeUI();

        // Load saved preferences
        loadPreferences();

        // Initial render
        renderAppearance();
    }

    private void initializeUI() {
        seekBarOpacity = findViewById(R.id.seekbar_opacity);
        seekBarTextSize = findViewById(R.id.seekbar_text_size);
        seekBarHealthBar = findViewById(R.id.seekbar_health_bar);
        radioGroupTheme = findViewById(R.id.radio_group_theme);

        // Set up seekbar listeners
        seekBarOpacity.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                float opacity = progress / 10f;
                viewSetVisualizerOpacity(opacity);
                findViewById(R.id.text_opacity_value).setText(String.format("%.0f%%", opacity * 100));
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });

        seekBarTextSize.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                float textSize = 12 + (progress * 0.5f);
                viewSetTextSize(textSize);
                findViewById(R.id.text_text_size_value).setText(String.format("%.1fpx", textSize));
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });

        seekBarHealthBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                // Health bar style selection
                int style = progress;
                viewSetHealthBarStyle(style);
                findViewById(R.id.text_health_style_value).setText(getHealthBarStyleName(style));
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });

        // Theme radio group listener
        radioGroupTheme.setOnCheckedChangeListener((group, checkedId) -> {
            int selectedThemeId = radioGroupTheme.getCheckedRadioButtonId();
            viewSetTheme(selectedThemeId);
        });
    }

    private void loadPreferences() {
        // Load saved appearance preferences
        // Opacity: 0.0 - 1.0
        float savedOpacity = viewModel.getVisualizerOpacity();
        seekBarOpacity.setProgress((int)(savedOpacity * 10));

        // Text size
        float savedTextSize = viewModel.getTextSize();
        seekBarTextSize.setProgress((int)((savedTextSize - 12) / 0.5f));

        // Health bar style
        int savedHealthStyle = viewModel.getHealthBarStyle();
        seekBarHealthBar.setProgress(savedHealthStyle);

        // Theme
        int savedTheme = viewModel.getThemeIndex();
        if (savedTheme >= 0 && savedTheme < radioGroupTheme.getChildCount()) {
            radioGroupTheme.check(radioGroupTheme.getChildAt(savedTheme).getId());
        }
    }

    private void renderAppearance() {
        // Apply saved settings to visualizer
        // The VisualizerView will use these settings when rendering
        visualizerView.invalidate();
    }

    private void viewSetVisualizerOpacity(float opacity) {
        viewModel.setVisualizerOpacity(opacity);
        // Apply opacity to visualizer - would affect box alpha, etc.
    }

    private void viewSetTextSize(float textSize) {
        viewModel.setTextSize(textSize);
        // Apply text size to visualizer labels
    }

    private void viewSetHealthBarStyle(int style) {
        viewModel.setHealthBarStyle(style);
        // Apply health bar style customization
    }

    private void viewSetTheme(int selectedThemeId) {
        viewModel.setThemeIndex(selectedThemeId);
        // Apply theme - would recreate activity or update colors
        switch (selectedThemeId) {
            case R.id.rb_theme_blue:
                // Blue theme - already default
                break;
            case R.id.rb_theme_green:
                // Green theme
                break;
            case R.id.rb_theme_red:
                // Red theme
                break;
            case R.id.rb_theme_purple:
                // Purple theme
                break;
            case R.id.rb_theme_custom:
                // Custom theme
                break;
        }
    }

    private String getHealthBarStyleName(int style) {
        String[] styles = {"Default", "Gradient", "Segmented", "Pulsing", "Custom"};
        return styles[style] + (style < styles.length - 1 ? "" : " *");
    }
}