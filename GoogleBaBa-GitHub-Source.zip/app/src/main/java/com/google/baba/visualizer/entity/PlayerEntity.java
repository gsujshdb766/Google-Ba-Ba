package com.google.baba.visualizer.entity;

/**
 * Represents a simulated player or bot entity in the visualizer.
 * All data is simulated/authorized for offline demonstration purposes.
 */
public class PlayerEntity {

    private String id;
    private EntityType entityType;
    private boolean isBot; // Explicit field for bot/human classification
    private String name;
    private float distance; // Distance from visualizer center
    private int health; // 0-100 health value
    private float[] position; // X, Y coordinates
    private List<float[]> skeletonPoints; // Joint positions for skeleton visualization
    private String direction; // Cardinal direction
    private String status; // Player status (Alive, Running, etc.)

    // Constructor
    public PlayerEntity() {
        this.id = "";
        this.entityType = EntityType.HUMAN;
        this.isBot = false;
        this.name = "Unnamed";
        this.distance = 0f;
        this.health = 100;
        this.position = new float[]{0f, 0f};
        this.skeletonPoints = new ArrayList<>();
        this.direction = "N";
        this.status = "Idle";
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EntityType getEntityType() {
        return entityType;
    }

    public void setEntityType(EntityType entityType) {
        this.entityType = entityType;
    }

    public boolean isBot() {
        return isBot;
    }

    public void setBot(boolean bot) {
        isBot = bot;
    }

    // The isBot field is the authoritative classification source.
    // When Ignore Bots feature is enabled, entities with isBot=true are hidden.

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public float[] getPosition() {
        return position;
    }

    public void setPosition(float[] position) {
        this.position = position;
    }

    public List<float[]> getSkeletonPoints() {
        return skeletonPoints;
    }

    public void setSkeletonPoints(List<float[]> skeletonPoints) {
        this.skeletonPoints = skeletonPoints;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Enum for entity type

    public enum EntityType {
        HUMAN,
        BOT
    }

    // String representations

    @Override
    public String toString() {
        return "PlayerEntity{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", isBot=" + isBot +
                ", distance=" + distance +
                ", health=" + health +
                ", direction=" + direction +
                ", status='" + status + '\'' +
                '}';
    }
}