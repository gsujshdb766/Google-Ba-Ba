package com.google.baba.visualizer.demomode;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.baba.visualizer.R;
import com.google.baba.visualizer.visualizer.VisualizerView;
import com.google.baba.visualizer.visualizer.VisualizerViewModel;

/**
 * Demo Mode screen for testing the visualizer with simulated human and bot entities.
 * Users can test the Ignore Bots switch, adjust simulation parameters, and reset the demo.
 */
public class DemoModeActivity extends AppCompatActivity {

    private VisualizerView visualizerView;
    private VisualizerViewModel viewModel;
    private int simulationHumans;
    private int simulationBots;
    private float simulationSpeed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_mode);

        // Initialize UI components
        visualizerView = findViewById(R.id.visualizerView);
        viewModel = new VisualizerViewModel();

        // Initialize simulation parameters from saved preferences
        simulationHumans = getSharedPreferences().getInt("simulation_humans", 5);
        simulationBots = getSharedPreferences().getInt("simulation_bots", 3);
        simulationSpeed = getSharedPreferences().getFloat("simulation_speed", 1.0f);

        // Set up UI listeners
        initializeUI();

        // Initial render
        renderDemo();
    }

    private void initializeUI() {
        // Demo mode toggle
        findViewById(R.id.toggle_demo_mode).setOnClickListener(v -> {
            boolean isOn = ((android.widget.CompoundButton) v).isChecked();
            viewModel.setDemoMode(isOn);
            renderDemo();
        });

        // Ignore bots toggle
        findViewById(R.id.toggle_ignore_bots).setOnClickListener(v -> {
            boolean isOn = ((android.widget.CompoundButton) v).isChecked();
            viewModel.setIgnoreBots(isOn);
            renderDemo();
        });

        // Human count seekbar/slider
        findViewById(R.id.seekbar_humans).setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                simulationHumans = progress;
                updateSimulationParams();
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });

        // Bot count seekbar/slider
        findViewById(R.id.seekbar_bots).setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                simulationBots = progress;
                updateSimulationParams();
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });

        // Simulation speed seekbar
        findViewById(R.id.seekbar_speed).setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                simulationSpeed = progress / 10f;
                findViewById(R.id.text_speed_value).setText(String.format("%.1f", simulationSpeed));
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });

        // Reset demo button
        findViewById(R.id.btn_reset_demo).setOnClickListener(v -> resetDemo());

        // Apply settings button
        findViewById(R.id.btn_apply_settings).setOnClickListener(v -> applySettings());
    }

    private void updateSimulationParams() {
        // Save preferences
        getSharedPreferences().edit()
                .putInt("simulation_humans", simulationHumans)
                .putInt("simulation_bots", simulationBots)
                .apply();

        // Reinitialize demo data with new parameters
        viewModel.initializeDemoData();
        renderDemo();
    }

    private void resetDemo() {
        // Reset to initial state
        simulationHumans = 5;
        simulationBots = 3;
        simulationSpeed = 1.0f;

        // Update UI
        findViewById(R.id.seekbar_humans).setProgress(simulationHumans);
        findViewById(R.id.seekbar_bots).setProgress(simulationBots);
        findViewById(R.id.seekbar_speed).setProgress((int)(simulationSpeed * 10));
        findViewById(R.id.text_speed_value).setText(String.format("%.1f", simulationSpeed));

        // Reset demo data
        viewModel.initializeDemoData();
        renderDemo();
    }

    private void applySettings() {
        // Apply the current settings and return to dashboard
        viewModel.setDemoMode(true);
        viewModel.setIgnoreBots(((android.widget.CompoundButton) findViewById(R.id.toggle_ignore_bots)).isChecked());
        renderDemo();
    }

    private void renderDemo() {
        // Get visible entities based on ignore bots filter
        boolean ignoreBots = viewModel.isIgnoreBots();
        List<PlayerEntity> visibleEntities = viewModel.getVisibleEntities();

        // Update the visualizer view
        visualizerView.setEntitiesAndOptions(
                visibleEntities,
                true, // showBox
                true, // showName
                true, // showDistance
                true, // showHealth
                true, // showSkeleton
                true, // showDirection
                true  // showStatus
        );

        // Update UI counters
        updateDemoCounters(visibleEntities, ignoreBots);
    }

    private void updateDemoCounters(List<PlayerEntity> entities, boolean ignoreBots) {
        int playerCount = entities.size();
        int humanCount = 0;
        int botCount = 0;

        for (PlayerEntity entity : entities) {
            if (entity.isBot()) {
                botCount++;
            } else {
                humanCount++;
            }
        }

        // Update UI text
        findViewById(R.id.tv_player_count).setText(String.valueOf(playerCount));
        findViewById(R.id.tv_human_count).setText(String.valueOf(humanCount));
        findViewById(R.id.tv_bot_count).setText(String.valueOf(botCount));

        // Update ignore bots text
        findViewById(R.id.tv_ignore_bots_status).setText(
                ignoreBots ? R.string.ignore_bots_on : R.string.ignore_bots_off
        );
    }
}