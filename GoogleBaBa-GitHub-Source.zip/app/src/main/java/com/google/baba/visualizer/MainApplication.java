package com.google.baba.visualizer;

import android.app.Application;
import android.content.SharedPreferences;
import androidx.preference.PreferenceManager;

public class MainApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize any global components here
    }

    public static SharedPreferences getSharedPreferences() {
        return PreferenceManager.getDefaultSharedPreferences(MainApplication.getInstance());
    }

    public static MainApplication getInstance() {
        return (MainApplication) getAppContext();
    }

    public static Context getAppContext() {
        return getInstance().getApplicationContext();
    }
}