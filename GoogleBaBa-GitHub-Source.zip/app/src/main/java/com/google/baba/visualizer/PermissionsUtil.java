package com.google.baba.visualizer;

import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Utility class for runtime permission handling.
 * Google Ba Ba only requests permissions that are explicitly needed
 * and handles them properly in the activity lifecycle.
 */
public class PermissionsUtil {

    // Request codes for different permission groups
    private static final int PERMISSION_REQUEST_CODE = 1001;

    /**
     * Checks if a permission is already granted.
     *
     * @param activity the current activity
     * @param permission the permission to check (e.g., "android.permission.WRITE_EXTERNAL_STORAGE")
     * @return true if the permission is granted, false otherwise
     */
    public static boolean isPermissionGranted(Activity activity, String permission) {
        return ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests a permission from the user.
     * Should be called from an Activity.
     *
     * @param activity the current activity
     * @param permission the permission to request
     * @param rationaleMessage message to show if the user needs to be explained why the permission is needed
     */
    public static void requestPermission(Activity activity, String permission, String rationaleMessage) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
            // User has previously denied the permission; show a rationale
            // In a real app, show a dialog with the rationaleMessage
        }
        ActivityCompat.requestPermissions(activity, new String[]{permission}, PERMISSION_REQUEST_CODE);
    }

    /**
     * Handles the permission request result.
     * Should be called from onRequestPermissionsResult in the Activity.
     *
     * @param requestCode the request code
     * @param grantResults the grant results from the system
     * @return true if the permission was granted, false otherwise
     */
    public static boolean handlePermissionResult(int requestCode, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.length > 0) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    return false; // Permission denied
                }
            }
            return true; // All permissions granted
        }
        return false;
    }

    /**
     * Checks and requests storage permission if needed.
     * Only requests WRITE_EXTERNAL_STORAGE for SDK < 33, as Scoped Storage is used otherwise.
     *
     * @param activity the current activity
     * @return true if permission is granted or was successfully requested, false if denied
     */
    public static boolean requestStoragePermission(Activity activity) {
        // For Android 11 (SDK 33) and above, scoped storage is used,
        // and WRITE_EXTERNAL_STORAGE is not needed for most operations
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            // Scoped storage - no permission needed for external files app owns
            return true;
        }

        // For older versions, check and request WRITE_EXTERNAL_STORAGE
        if (isPermissionGranted(activity, android.permission.WRITE_EXTERNAL_STORAGE)) {
            return true;
        }

        requestPermission(activity, android.permission.WRITE_EXTERNAL_STORAGE,
                "Permission needed to save screenshots and exported data");
        return false; // Permission request is in progress
    }
}