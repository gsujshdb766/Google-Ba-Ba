# Google Ba Ba - Android ESP-Style Visualizer

## Project Overview
Advanced Android ESP-Style Visualizer Application for offline demonstrations and simulated gameplay environments.

## Package Name
`com.google.baba.visualizer`

## Project Structure
- **Splash Screen** → **Welcome Screen** → **Main Dashboard** → **Visualizer/Demo Mode/Player Settings/Appearance/General/About**

## Build Requirements
- **JDK**: 17 (OpenJDK)
- **Gradle**: 8.4 (wrapper included)
- **Android SDK**: 34 (target), 21 (min)
- **Android Gradle Plugin**: Compatible with Gradle 8.4 and SDK 34

## Local Build (Android Studio)
1. Open Android Studio
2. File → Open → select `googlebaba/` directory
3. Wait for Gradle sync
4. Build → Build APK(s) / Build Bundle(s)

## GitHub Actions Build
Uses `android-actions` to set up the Android SDK and build the debug APK.

## Repository Files
- `googlebaba/` - Android Studio project directory
- `gradlew` - Gradle wrapper (executable)
- `build.gradle` - Project and module build configurations
- `settings.gradle` - Project settings
- `.github/workflows/android-build.yml` - GitHub Actions workflow

## CI/CD
See `.github/workflows/android-build.yml` for the build configuration.
```

